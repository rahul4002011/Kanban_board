
import React from 'react';

const SortSelector = ({ setSortOption }) => {
  return (
    <div>
      <h2>Sort By:</h2>
      <button onClick={() => setSortOption('priority')}>Priority</button>
      <button onClick={() => setSortOption('title')}>Title</button>
    </div>
  );
};

export default SortSelector;
