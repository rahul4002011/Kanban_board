
import React, { useState, useEffect } from 'react';
import TicketCard from './Ticketcard';
import GroupSelector from './GroupSelector';
import SortSelector from './SortSelector';

const KanbanBoard = () => {
  const [tickets, setTickets] = useState([]);
  const [groupOption, setGroupOption] = useState('status');
  const [sortOption, setSortOption] = useState('priority');

  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const response = await fetch('https://api.quicksell.co/v1/internal/frontend-assignment');
        console.log(response);
        const data = await response.json();
        setTickets(data.tickets); 
      } catch (error) {
        console.error('Error fetching tickets:', error);
      }
    };

    fetchTickets();
  }, []);

  // const groupTickets = (tickets, groupOption) => {
  //   switch (groupOption) {
  //     case 'status':
  //       return groupByStatus(tickets);
  //     case 'user':
  //       return groupByUser(tickets);
  //     case 'priority':
  //       return groupByPriority(tickets);
  //     default:
  //       return tickets;
  //   }
  // };

  // const sortTickets = (tickets, sortOption) => {
  //   switch (sortOption) {
  //     case 'priority':
  //       return [...tickets].sort((a, b) => b.priority - a.priority);
  //     case 'title':
  //       return [...tickets].sort((a, b) => a.title.localeCompare(b.title));
  //     default:
  //       return tickets;
  //   }
  // };

  // const groupedTickets = groupTickets(tickets, groupOption);
  // const sortedTickets = sortTickets(groupedTickets, sortOption);

  return (
    <div>
      {/* <GroupSelector setGroupOption={setGroupOption} />
      <SortSelector setSortOption={setSortOption} />
      <div className="kanban-board">
        {Object.keys(sortedTickets).map(group => (
          <div className="kanban-column" key={group}>
            <h2>{group}</h2>
            {sortedTickets[group].map(ticket => (
              <TicketCard key={ticket.id} ticket={ticket} />
            ))}
          </div>
        ))}
      </div> */}
    </div>
  );
};

const groupByStatus = (tickets) => {
  return tickets.reduce((acc, ticket) => {
    acc[ticket.status] = acc[ticket.status] || [];
    acc[ticket.status].push(ticket);
    return acc;
  }, {});
};

const groupByUser = (tickets) => {
  return tickets.reduce((acc, ticket) => {
    acc[ticket.userId] = acc[ticket.userId] || [];
    acc[ticket.userId].push(ticket);
    return acc;
  }, {});
};

const groupByPriority = (tickets) => {
  return tickets.reduce((acc, ticket) => {
    const priorityLevel = ticket.priority;
    acc[priorityLevel] = acc[priorityLevel] || [];
    acc[priorityLevel].push(ticket);
    return acc;
  }, {});
};

export default KanbanBoard;
