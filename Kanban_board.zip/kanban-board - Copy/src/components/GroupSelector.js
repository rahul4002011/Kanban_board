// src/components/GroupSelector.js
import React from 'react';

const GroupSelector = ({ setGroupOption }) => {
  return (
    <div>
      <h2>Group By:</h2>
      <button onClick={() => setGroupOption('status')}>Status</button>
      <button onClick={() => setGroupOption('user')}>User</button>
      <button onClick={() => setGroupOption('priority')}>Priority</button>
    </div>
  );
};

export default GroupSelector;
