import React from 'react';
import KanbanBoard from './components/KanbanBoard'; // Importing KanbanBoard component
import './App.css'; // Importing the CSS file

function App() {
  return (
    <div className="App">
      <h1>Kanban Board</h1> {/* Title for the Kanban board */}
      <KanbanBoard /> {/* Rendering the KanbanBoard component */}
    </div>
  );
}

export default App;
